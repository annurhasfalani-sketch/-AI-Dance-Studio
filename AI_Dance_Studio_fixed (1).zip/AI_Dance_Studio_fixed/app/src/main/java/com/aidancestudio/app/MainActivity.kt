package com.aidancestudio.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF111827)
private val Lime = Color(0xFFB7F34A)
private val Muted = Color(0xFF64748B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DanceApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DanceApp() {
    var photo by remember { mutableStateOf<Uri?>(null) }
    var danceVideo by remember { mutableStateOf<Uri?>(null) }
    var duration by remember { mutableIntStateOf(5) }
    var notice by remember { mutableStateOf("Pilih foto dan video referensi untuk memulai.") }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { photo = it; if (it != null) notice = "Foto karakter berhasil dipilih." }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { danceVideo = it; if (it != null) notice = "Video referensi berhasil dipilih." }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Ink, secondary = Lime, background = Color(0xFFF5F7FA)
    )) {
        Scaffold(containerColor = Color(0xFFF5F7FA)) { pad ->
            Column(
                modifier = Modifier.fillMaxSize().padding(pad)
                    .verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(24.dp)).padding(20.dp)
                ) {
                    Text("AI DANCE STUDIO", color = Lime, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    Text("Buat video joget dari foto dan video gerakan", color = Color.White, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("VERSI UJI COBA • GRATIS", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Text("1. Bahan video", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                PickerCard(
                    title = "Foto karakter",
                    subtitle = if (photo == null) "Pilih foto seluruh badan dari galeri" else "Foto sudah dipilih",
                    icon = Icons.Default.Person,
                    selected = photo != null,
                    onClick = { photoPicker.launch("image/*") }
                )
                PickerCard(
                    title = "Video referensi joget",
                    subtitle = if (danceVideo == null) "Pilih video gerakan dari galeri" else "Video sudah dipilih",
                    icon = Icons.Default.Videocam,
                    selected = danceVideo != null,
                    onClick = { videoPicker.launch("video/*") }
                )

                Text("2. Pengaturan hasil", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Durasi video", fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(5, 10, 13).forEach { seconds ->
                                FilterChip(
                                    selected = duration == seconds,
                                    onClick = { duration = seconds },
                                    label = { Text("$seconds detik") }
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ScreenRotation, contentDescription = null, tint = Muted)
                            Spacer(Modifier.width(8.dp))
                            Text("Format vertikal 9:16", color = Ink)
                        }
                    }
                }

                Button(
                    onClick = { notice = "Antarmuka siap. Mesin AI Motion Control belum terhubung, jadi video belum dapat diproses." },
                    enabled = photo != null && danceVideo != null,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Ink, disabledContainerColor = Color(0xFFCBD5E1))
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Lime)
                    Spacer(Modifier.width(8.dp))
                    Text("SIAPKAN VIDEO", color = Color.White, fontWeight = FontWeight.Bold)
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6E5))) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Status percobaan", fontWeight = FontWeight.Bold, color = Ink)
                        Spacer(Modifier.height(4.dp))
                        Text(notice, color = Ink, fontSize = 13.sp)
                    }
                }

                Text(
                    "Catatan: aplikasi ini belum mengirim foto/video ke server AI. Integrasi model Motion Control gratis akan ditambahkan setelah endpoint GPU gratis yang dapat dipakai ditemukan. Jangan unggah konten pribadi/sensitif.",
                    color = Muted, fontSize = 11.sp, lineHeight = 16.sp
                )
                Text("AI Dance Studio • v0.1.0", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun PickerCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(48.dp).background(if (selected) Color(0xFFEAF8D8) else Color(0xFFF1F5F9), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Ink)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Ink)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(if (selected) Icons.Default.CheckCircle else Icons.Default.AddCircleOutline,
                contentDescription = null, tint = if (selected) Color(0xFF4D8A16) else Muted)
        }
    }
}
