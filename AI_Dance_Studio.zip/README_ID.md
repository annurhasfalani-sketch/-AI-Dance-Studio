# AI Dance Studio Android — v0.1.0

## Status
Ini adalah **prototipe aplikasi Android**, bukan APK siap pasang. Proyek menyediakan antarmuka untuk memilih foto karakter dan video referensi, memilih durasi, dan format 9:16.

## Yang belum berfungsi
Tombol "Siapkan Video" belum menjalankan AI. Belum ada backend Motion Control/GPU yang terhubung. Menghubungkan model seperti Wan Animate membutuhkan server GPU, penyimpanan sementara, antrean pekerjaan, dan endpoint inferensi. Kuota gratis pihak ketiga tidak dapat dijamin.

## Cara membuka proyek
1. Instal Android Studio di komputer.
2. Buka folder proyek ini.
3. Biarkan Gradle menyinkronkan dependensi.
4. Jalankan pada emulator atau perangkat Android.

## Persyaratan
- Android minimum: Android 8.0 (API 26)
- Target SDK: 35
- Kotlin + Jetpack Compose

## Rencana tahap berikutnya
1. Uji pemilih foto/video di perangkat.
2. Pilih penyedia inferensi yang benar-benar menyediakan kuota gratis.
3. Buat backend aman (jangan menaruh API key di APK).
4. Hubungkan antrean dan status pekerjaan.
5. Uji hasil, biaya, watermark, dan kebijakan privasi.

## Privasi
Versi ini hanya membuka pemilih file Android. File tidak diunggah ke mana pun.

## Build APK lewat HP menggunakan GitHub Actions
1. Buat repository GitHub baru (public untuk menghindari kuota Actions private).
2. Ekstrak ZIP di HP, lalu unggah isi folder proyek ke repository. Jangan unggah file ZIP saja.
3. Pastikan folder `.github/workflows/android.yml` ikut terunggah.
4. Buka tab Actions pada repository dan jalankan workflow `Build Android APK` jika belum berjalan otomatis.
5. Setelah status hijau, buka run tersebut, cari bagian Artifacts, lalu unduh `AI-Dance-Studio-debug-apk`.
6. Ekstrak ZIP artifact dan pasang `app-debug.apk` di Android.

Catatan: build APK melalui GitHub Actions tersedia sesuai batas dan kebijakan akun GitHub. Jangan memasukkan password, token, atau kunci rahasia ke repository.
